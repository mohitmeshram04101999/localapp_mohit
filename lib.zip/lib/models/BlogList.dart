class Blog_list{

  String BlogPostId='';
  String Heading='';
  String Text='';
  String PostDisplayPhoto='';
  String  status='';
  String TimeAgo='';
  String SubCategoryName='';
  String VideoLink;

  List<Blog_list> data=[];

  Blog_list({
    required this.BlogPostId,
    required this.Heading,
    required this.Text,
    required this.PostDisplayPhoto,
    required this.TimeAgo,
    required this.SubCategoryName,
    required this.VideoLink

  });

  factory Blog_list.fromJson(Map<String, dynamic> json) {
    return Blog_list(
      BlogPostId: json['BlogPostId'] as String,
      Heading: json['Heading'] as String,
      Text: json['Text'] as String,
      PostDisplayPhoto: json['PostDisplayPhoto']==null?'': json['PostDisplayPhoto'] as String,
      TimeAgo: json['TimeAgo']==null?'': json['TimeAgo'] as String,
      SubCategoryName: json['SubCategoryName']==null?'': json['SubCategoryName'] as String,
      VideoLink: json['VideoLink']==null?'': json['VideoLink'] as String,



    );
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['data'] = this.data.map((v) => v.toJson()).toList();
    return data;
  }
}



