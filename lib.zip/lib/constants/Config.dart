class Config
{
  static String Main_Link = "https://shubhapp.com/local_app/api/";
  static String Image_Path = "https://shubhapp.com/local_app/uploads/";
  static String signup = Main_Link+"signup";
  static String get_home = Main_Link+"get_home";
  static String get_city = Main_Link+"get_city";
  static String get_city_area = Main_Link+"get_city_area";
  static String get_contacts = Main_Link+"get_contacts";
  static String get_blogs = Main_Link+"get_blogs";
  static String get_sub_category = Main_Link+"get_sub_category";
  static String get_blog_data = Main_Link+"get_blog_data";
  static String get_user_post_category = Main_Link+"get_user_post_category";
  static String get_search_city_area = Main_Link+"get_search_city_area";
  static String get_area_home = Main_Link+"get_area_home";
  static String get_contact_home = Main_Link+"get_contact_home";
  static String get_search_area_home = Main_Link+"get_search_area_home";
  static String get_directory_data = Main_Link+"get_directory_data";


}